<?php
session_start();

$host = "localhost";
$db_username = "root";
$db_password = "";
$database = "login_db"
?>